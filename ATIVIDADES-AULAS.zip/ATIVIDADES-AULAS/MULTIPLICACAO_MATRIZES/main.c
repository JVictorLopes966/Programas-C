#include <stdio.h>
#include "colors.h"

int main(void) {
    int A[2][3] = {1, 1, 2, 3, 4, 5};
    int B[3][2] = {1, 2, 3, 4, 5, 6};
    int C[2][2] = {0, 0, 0, 0};

    int i = 0; //Linhas de A
    int j = 0; // Colunas de B
    int k = 0; // Parametro pra percorrer as matrizes

    for(i=0;i<2;i++){
        for(j=0;j<2;j++){
            for(k=0;k<3;k++){
                C[i][j] = C[i][j] + A[i][k] * B[k][j];
            }
        }
    }

    for (i=0;i<2;i++) {
        for (j=0;j<2;j++) {
            printf( VERMELHO"[%d]"RESET, C[i][j]);
        }
        printf("\n");
    }
    return 0;
}

