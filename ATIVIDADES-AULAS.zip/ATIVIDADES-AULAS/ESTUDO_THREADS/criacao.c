
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
void * funcaoThread(void *arg){
    printf("Thread iniciada!\n");
    return NULL;
}

int main(void){
    pthread_t thread_id;
    pthread_create(&thread_id, NULL, funcaoThread, NULL);
    pthread_join(thread_id, NULL);
    printf("Thread principal finalizada.\n");
    
    
    return 0;
}