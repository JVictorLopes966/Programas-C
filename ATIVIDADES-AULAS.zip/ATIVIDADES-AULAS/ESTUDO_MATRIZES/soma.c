#include <stdio.h>

int main(void){
    int A[2][3] = {1, 2, 4, 5, 6, 7};
    
    int l = 0;
    int c = 0;
    int sum = 0; //utilizar o double e recomendado 
    for(l=0;l<2;l++){
        for(c=0;c<3;c++){
            sum += A[l][c];
        }
    }

    printf("%d", sum);
    return 0;
}