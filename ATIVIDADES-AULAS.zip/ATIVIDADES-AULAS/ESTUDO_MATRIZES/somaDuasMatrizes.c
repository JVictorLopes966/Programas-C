#include <stdio.h>
int main(void){

    int A[2][2] = {1, 2, 3, 4};
    int B[2][2] = {6, 5, 3, 2};
    int C[2][2] = {0, 0, 0, 0};
    int i = 0;
    int k = 0;
    int j = 0;

    for(i=0;i<3;i++){
        for(k=0;k<3;k++){
            for(j=0;j<3;j++){
                C[i][k] = A[i][k] + B[i][k];
            }
        }
    }
    for(i=0;i<2;i++){
        printf("\n");
        for(k=0;k<2;k++){
            printf("[%d]", C[i][j]);
        }
    }

    return 0;
}