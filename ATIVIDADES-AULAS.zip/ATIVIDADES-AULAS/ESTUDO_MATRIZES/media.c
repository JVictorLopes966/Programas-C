#include <stdio.h>

int main(void){
    int A[2][3] = {1, 2, 4, 5, 6, 7};
    
    int l = 0;
    int c = 0;
    double sum = 0;
    double media = 0;
    for(l=0;l<2;l++){
        for(c=0;c<3;c++){
            sum += A[l][c];
        }
    }
    media = sum / (sizeof(A)/ sizeof(A[2][3]));
    printf("SOMA: %.2f\n", sum);
    printf("MEDIA: %.2f\n", media);
    return 0;
}