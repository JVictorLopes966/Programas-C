#include <stdio.h>

int main(void){

    int A[2][3] = {1, 2, 3, 4, 5, 6};
    int i = 0;
    int k = 0;
    int max = 0

    for(i=0; i<2;i++){
        for(k=0;k<3;k++){
            if(A[i][k] > max){
                max = A[i][k];
            }
        }
    }
    printf("%d", max);   



    return 0;
}