#include <stdio.h>
#include <stdlib.h>
#include "colors.h"

int main(void) {
    float peso, altura, imc;
    printf("Digite o seu peso em kg: ");
    scanf("%f", &peso);

    printf("Digite a sua altura: ");
    scanf("%f", &altura);

    if ( peso <= 0 || altura <= 0) {
        printf("Pesos e alturas com valores inválidos: ");
    }
    imc = peso/pow(altura, 2);
    printf("Seu IMC e: %.2f", imc);

    printf("CLASSIFICACAO: \n");

    if (imc < 18.5) {
        system(VERMELHO, RESET)
    } else if (imc < 25.0) {
        printf("Peso Normal\n");
    } else if (imc < 30.0) {
        printf("Sobrepeso\n");
    } else if (imc < 35.0) {
        printf("Obesidade Grau I\n");
    } else if (imc < 40.0) {
        printf("Obesidade Grau II (severa)\n");
    } else if (imc < 45.0) {
        printf("Obesidade Grau III(mórbida)\n");
    }

}
