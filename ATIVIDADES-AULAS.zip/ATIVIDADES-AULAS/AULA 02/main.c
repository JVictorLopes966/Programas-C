#include <stdio.h>;

int main(void){
    int bebida;
    printf("Qual bebida você quer tomar? [1-Água][2-Refrigerante][3-Suco] ");
    scanf("%d", &bebida);

    switch (bebida)
    {
    case 1:
        printf("Você escolheu Água");
        break;
    case 2:
        printf("Você escolher Refrigerante");
        break;
    case 3:
        printf("Você escolheu Suco");
        break;
    default:
        printf("Opção Inválida");
        break;
    }

    return 0;
}